package assegnamento1;

public class MainApplication {

	public static void main(String[] args) {
		MasterNode masterNode = new MasterNode();
		masterNode.start();

	}

}
